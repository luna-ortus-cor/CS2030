public class DoneEvent extends Event {

    /**
     * constructor for done event.
     * @param c customer
     * @param eventTime event time
     */
    public DoneEvent(Customer c, int sID, double eventTime) {
        super(c, sID, eventTime);
    }
    
    /**
     * return event, modified server list, customer list, and string output.
     * @param svrList original server list
     * @param custList customer list
     */
    public Pair<Event, Pair<ImList<Server>, ImList<Customer>>> 
        execute(ImList<Server> svrList, ImList<Customer> custList) {
        Server s1 = svrList.get(super.sID - 1);
        Pair<Integer, Server> p = s1.serve();
        Server s2 = p.second();
        if (s2.getQ().qLength() == 0) {
            svrList = svrList.set(s2.getID() - 1, new Server(s2.getID() - 1, s2.getQ()));
            return new Pair<Event, Pair<ImList<Server>, ImList<Customer>>>(
                this, new Pair<ImList<Server>, ImList<Customer>>(
                    svrList, custList));
        } else {
            // svrList will set s2 to a "free" server 
            // but this will immediately be followed by a serve event
            svrList = svrList.set(s2.getID() - 1, new Server(s2.getID() - 1, s2.getQ()));
            return new Pair<Event, Pair<ImList<Server>, ImList<Customer>>>(
                new ServeEvent(custList.get(p.first() - 1), s2.getID(), super.eventTime), 
                    new Pair<ImList<Server>, ImList<Customer>>(svrList, custList));
        }
    }

    @Override
    public String toString() {
        return String.format("%.3f %d done serving by %d\n",
            super.eventTime, super.c.getID(), super.sID);
    }
}
