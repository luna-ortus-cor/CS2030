import java.util.Comparator;

public class Customer implements Comparable<Customer> {
    private final double arriveTime;
    private final Supplier<Double> svcTime;
    private final int cID;
    private final int state; // 0 for leave, 1 for serve
    private final double endTime;
    private final double serveTime;

    /**
     * constructor for customer. 
     * @param cID customer id
     * @param arriveTime arrive time
     * @param serveTime serve time
     */
    //public Customer(int cID, double arriveTime, double serveTime) {
    public Customer(int cID, double arriveTime, Service<Double> svcTime) {
        this.arriveTime = arriveTime;
        this.svcTime = svcTime;
        this.cID = cID;
        this.state = 0;
        this.endTime = 0;
        this.serveTime = 0;
    }

    /**
     * alternate constructor for customer.
     * @param cID customer id
     * @param arriveTime arrive time
     * @param serveTime serve time
     * @param state state
     */
    public Customer(int cID, double arriveTime, Service<Double> svcTime, 
        double serveTime, double endTime, int state) {
        this.arriveTime = arriveTime;
        this.svcTime = svcTime;
        this.cID = cID;
        this.state = state;
        this.serveTime = serveTime;
        this.endTime = endTime;
    }

    @Override
    public String toString() {
        return String.format("%.3f %d arrives\n", this.arriveTime, this.cID);
    }

    /**
     * get end time.
     */
    public double getEnd() {
        if (this.endTime == 0 ) {
            return this.arriveTime + this.serveTime;
        } else {
            return this.endTime;
        }
    } 
    
    /**
     * get customer id.
     */
    public int getID() {
        return this.cID;
    }

    /**
     * get state.
     */
    public int getState() {
        return this.state;
    }

    /**
     * get arrive time.
     */
    public double getArrive() {
        return this.arriveTime;
    }

    /**
     * get serve time.
     */
    public double getServe() {
        return this.serveTime;
    }

    /**
     * get supplier.
     */
    public double getSupplier() {
        return this.svcTime;
    }

    @Override
    public int compareTo(Customer c) {
        if (this.arriveTime < c.arriveTime) {
            return -1;
        } else if (this.arriveTime > c.arriveTime) {
            return 1;
        } else {
            return 0;
        }
    }
}
