public class ArriveEvent extends Event {
    
    /**
     * constructor for arriveEvent.
     * @param c customer object
     * @param eventTime event time
     */
    public ArriveEvent(Customer c, double eventTime) {
        super(c, eventTime);
    }
    
    /**
     * returns event, modified server list, string output.
     * @param svrList original server list
     */
    public Pair<Event, Pair<ImList<Server>, ImList<Customer>>> //to check addding to q if waiting vs direct serve
                                                               //i think we need to modify svrList q always
                                                               //except if leave
        execute(ImList<Server> svrList, ImList<Customer> custList) {
        int minQ = -1;
        int minC = Integer.MAX_VALUE;
        for (int i = 0; i < svrList.size(); i++) {
            if (svrList.get(i).isFree(super.eventTime)) {
                svrList = svrList.set(i, new Server(i + 1, super.c.getEnd()));
                return new Pair<Event, Pair<ImList<Server>, ImList<Customer>>>(
                    new ServeEvent(super.c, i + 1, super.eventTime), 
                        new Pair<ImList<Server>, ImList<Customer>>(svrList, custList));
            } else {
                minQ = (svrList.get(i).qLength() < minC ? i : minC);
            }
        }
        if (minQ != -1) {
            return new Pair<Event, Pair<ImList<Server>, ImList<Customer>>>(
                new WaitEvent(super.c, minQ + 1, super.eventTime), 
                    new Pair<ImList<Server>, ImList<Customer>>(svrList, custList));
        } 
        return new Pair<Event, Pair<ImList<Server>, ImList<Customer>>>(
                new LeaveEvent(super.c, super.eventTime), 
                    new Pair<ImList<Server>, ImList<Customer>>(svrList, custList));
    }

    @Override
    public String toString() {
        return this.c.toString();
    }
}
