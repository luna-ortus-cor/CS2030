public class ServeEvent extends Event {

    /**
     * constructor for serve event.
     * @param c customer
     * @param eventTime event time
     */
    public ServeEvent(Customer c, int sID, double eventTime) {
        super(c, sID, eventTime);
    }

    /**
     * return event, server list, customer list.
     * @param svrList server list
     * @param custList customer list
     */
    public Pair<Event, Pair<ImList<Server>, ImList<Customer>>> 
        execute(ImList<Server> svrList, ImList<Customer> custList) {
        double serveTime = super.c.getSupplier().get();
        Customer c1 = super.c;
        double c1Svc = c1.getSupplier().get();
        Server s1 = svrList.get(super.sID - 1);
        Customer c2 = new Customer(c1.getID(), c1.getArrive(), c1.getSupplier(), 1, 
            c1Svc, super.eventTime + c1Svc);
        Server s2 = new Server(s1.getID() - 1, c2.getEnd(), s1.getQ());
        custList = custList.set(c1.getID() - 1, c2);
        svrList = svrList.set(s1.getID() - 1, s2);
        return new Pair<Event, Pair<ImList<Server>, ImList<Customer>>>(
            new DoneEvent(c2, s2.getID(), c2.getEnd()),
                new Pair<ImList<Server>, ImList<Customer>>(svrList, custList));
    }

    @Override
    public String toString() {
        return String.format("%.3f %d serves by %d\n", 
            super.eventTime, super.c.getID(), super.sID);
    }
}
