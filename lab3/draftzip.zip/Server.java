public class Server {
    private final int state;
    private final int sID;
    private final double endTime;
    private final Queue custQ;
    
    /**
     * constructor for server.
     * @param sID server ID
     * @param custQ customer queue
     */
    public Server(int sID, Queue custQ) {
        this.sID = sID;
        this.state = 0;
        this.endTime = 0;
        this.custQ = custQ;
    }

    /**
     * constructor for server.
     * @param sID server ID
     * @param endTime end time
     * @param custQ customer queue
     */
    public Server(int sID, double endTime, Queue custQ) {
        this.sID = sID;
        this.state = 1;
        this.endTime = endTime;
        this.custQ = custQ;
    }

    /**
     * get server id.
     */
    public int getID() {
        return this.sID;
    }

    /**
     * get queue.
     */
    public Queue getQ() {
        return this.custQ;
    }

    @Override
    public String toString() {
        return String.format("server %d state %d busy until %f", 
            this.sID, this.state, this.endTime);
    }

    /**
     * check if server is free given time.
     * @param t current time
     */
    public boolean isFree(double t) {
        if (this.state == 0) {
            return true;
        } else if (this.state == 1 && this.endTime <= t && this.custQ.qLength() == 1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * server serves first customer in queue.
     */
    public Pair<Integer, Server> serve() { 
        //the assumption is we only call this when 
        //there is a serveevent, hence custQ will never be empty
        Pair<Integer, Queue> p = this.custQ.serve();
        //to take custQ max length from p.second() or from this.custQ ?
        return new Pair<Integer, Server>(p.first(), new Server(p.second(), this.custQ.getMax()));
    }
}
