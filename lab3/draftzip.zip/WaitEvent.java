class WaitEvent extends Event {


    /**
     * constructor for wait event
     */
    public WaitEvent(Customer c, int sID, double eventTime) {
        super(c, sID, eventTime);
    }
    
    public Pair<Event, Pair<ImList<Server>, ImList<Customer>>> 
        execute(ImList<Server> svrList, ImList<Customer> custList) {
        return new Pair<Event, Pair<ImList<Server>, ImList<Customer>>>(
            this, new Pair<ImList<Server>, ImList<Customer>>(svrList, custList));
    }

    @Override
    public String toString() {
        return String.format("%.3f %d waits at %d",super.eventTime,super.c.getID(),super.sID);
    }
}
    
